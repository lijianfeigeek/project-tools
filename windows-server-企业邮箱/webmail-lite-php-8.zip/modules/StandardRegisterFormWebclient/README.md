# Aurora Standard Register Form web client module
Displays standard register form with ability to specify user name, account login and password

# License
This module is licensed under AGPLv3 license if free version of the product is used or AfterLogic Software License if commercial version of the product was purchased.