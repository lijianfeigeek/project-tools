# Aurora Session Timeout web client module
System module which kill the user session on after expiry of the specified period of time

# License
This module is licensed under AGPLv3 license if free version of the product is used or AfterLogic Software License if commercial version of the product was purchased.