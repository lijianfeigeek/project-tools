# Aurora Google Auth webclient module
This module adds ability to login using Google account

# License
This module is licensed under AGPLv3 license if free version of the product is used or AfterLogic Software License if commercial version of the product was purchased.