# Aurora Settings web client module
This module displays the interface of user settings. The settings are provided by other modules.

# License
This module is licensed under AGPLv3 license if free version of the product is used or AfterLogic Software License if commercial version of the product was purchased.